package com.quiz.controller;

import com.quiz.entity.Quiz;
import com.quiz.service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/quiz")
public class QuizController {

    @Autowired
    private QuizService quizService;

    //quiz find all
    @GetMapping
    public List<Quiz> findAll(){
        return quizService.get();
    }
    //find by id
    @GetMapping("/{id}")
    public Quiz getById(@PathVariable Long id){
        return quizService.get(id);
    }

    @PostMapping
    public Quiz add(@RequestBody Quiz quiz){
        return quizService.add(quiz);
    }
}
